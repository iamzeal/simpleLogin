﻿USE [CHN12_MMS73_TEST]
GO

DECLARE	@return_value Int

EXEC	@return_value = [dbo].[CreateSRO]
		@sroid = NULL,
		@address1 = N'abc',
		@address2 = N'def',
		@area = N'sdf',
		@district = N'fdf',
		@state = N'dindigul',
		@country = N'india',
		@bankname = N'SBI',
		@bankaccount = 1376878888,
		@branch = N'dindigul',
		@ifsccode = N'egfh3425',
		@createdby = N'admin',
		@createddate = N'29/08/2106',
		@modifiedby = N'admin',
		@modifieddate = N'29/08/2106',
		@status = true

SELECT	@return_value as 'Return Value'

GO

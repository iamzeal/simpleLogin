﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using adminBO;
using BLL;
using DAL;
namespace CRUD2
{
    public partial class createsro : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                SROBO bo = new SROBO();
                bo.Address_1 = TextBox2.Text;
                bo.Address_2 = TextBox3.Text;
                bo.AreaLocation = TextBox4.Text;
                bo.District = DropDownList1.SelectedItem.Value;
                bo.State = DropDownList2.SelectedItem.Value;
                bo.Country = DropDownList3.SelectedItem.Value;
                bo.BankName = DropDownList4.SelectedItem.Value;
                bo.BankAccount =long.Parse(TextBox5.Text);
                bo.Branch = DropDownList5.SelectedItem.Value;
                bo.IFSCCode = TextBox6.Text;
                bo.Createdby = TextBox7.Text;
                bo.CreatedDate = DateTime.Parse(TextBox8.Text);
                bo.Modifiedby = TextBox9.Text;
                bo.ModifiedDate = DateTime.Parse(TextBox10.Text);
                bo.Status = Boolean.Parse(TextBox11.Text);
                SROBLL bllobj = new SROBLL();
                bllobj.addsro(bo);

            }

            SRODAL srodal = new SRODAL();
             int sroIdOnClient = srodal.alert();
             ScriptManager.RegisterStartupScript(this, GetType(), "showalert", "alert('"+sroIdOnClient +"');", true);

            
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AdminBO
{
    public class SRofficeBO
    {
        public int SROID;
        public string Address_1;
        public string Address_2;
        public string Area_Location;
        public string District;
        public string State;
        public string Country;
        public string Bank_Name;
        public long Bank_Account;
        public string Branch;
        public string IFSC_Code;
        public string Created_by;
        public DateTime Created_Date;
        public string Modified_by;
        public DateTime Modified_Date;
        public int Status;

        public int SROID1
        {
            get
            {
                return SROID;
            }

            set
            {
                SROID = value;
            }
        }

        public string Address_11
        {
            get
            {
                return Address_1;
            }

            set
            {
                Address_1 = value;
            }
        }

        public string Address_21
        {
            get
            {
                return Address_2;
            }

            set
            {
                Address_2 = value;
            }
        }

        public string Area_Location1
        {
            get
            {
                return Area_Location;
            }

            set
            {
                Area_Location = value;
            }
        }

        public string District1
        {
            get
            {
                return District;
            }

            set
            {
                District = value;
            }
        }

        public string State1
        {
            get
            {
                return State;
            }

            set
            {
                State = value;
            }
        }

        public string Country1
        {
            get
            {
                return Country;
            }

            set
            {
                Country = value;
            }
        }

        public string Bank_Name1
        {
            get
            {
                return Bank_Name;
            }

            set
            {
                Bank_Name = value;
            }
        }

        public long Bank_Account1
        {
            get
            {
                return Bank_Account;
            }

            set
            {
                Bank_Account = value;
            }
        }

        public string Branch1
        {
            get
            {
                return Branch;
            }

            set
            {
                Branch = value;
            }
        }

        public string IFSC_Code1
        {
            get
            {
                return IFSC_Code;
            }

            set
            {
                IFSC_Code = value;
            }
        }

        public string Created_by1
        {
            get
            {
                return Created_by;
            }

            set
            {
                Created_by = value;
            }
        }

        public DateTime Created_Date1
        {
            get
            {
                return Created_Date;
            }

            set
            {
                Created_Date = value;
            }
        }

        public string Modified_by1
        {
            get
            {
                return Modified_by;
            }

            set
            {
                Modified_by = value;
            }
        }

        public DateTime Modified_Date1
        {
            get
            {
                return Modified_Date;
            }

            set
            {
                Modified_Date = value;
            }
        }

        public int Status1
        {
            get
            {
                return Status;
            }

            set
            {
                Status = value;
            }
        } 
    }
}

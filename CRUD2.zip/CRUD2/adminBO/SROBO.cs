﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace adminBO
{
    public class SROBO
    {
        public int SROID { get; set; }
        public string Address_1 { get; set; }
        public string Address_2 { get; set; }
        public string AreaLocation { get; set; }
        public string District { get; set;}
        public string State { get; set; }
        public string Country { get; set; }
        public string BankName { get; set; }
        public long BankAccount { get; set; }
        public string Branch { get; set; }
        public string IFSCCode { get; set; }
        public string Createdby { get; set; }
        public DateTime CreatedDate { get; set; }
        public string Modifiedby { get; set; }
        public DateTime ModifiedDate { get; set; }
        public Boolean Status { get; set; }
    }
}

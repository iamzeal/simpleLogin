﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using adminBO;
using System.Data;
namespace DAL
{
    public class SRODAL
    {
        public static int sroid;
        static SqlConnection cn;
        static SqlCommand cmd;
        public int  create(SROBO bo)
        {
            string conStr = "Data Source=inchnilpdb02\\mssqlserver1;Initial Catalog=CHN32_MMS73_TEST;User ID=mms73user;Password=mms73user";
            cn = new SqlConnection(conStr);
            cn.Open();
            cmd = new SqlCommand("CreateSRO", cn); cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@adress1", bo.Address_1);
            cmd.Parameters.AddWithValue("@adress2", bo.Address_2);
            cmd.Parameters.AddWithValue("@area", bo.AreaLocation);
            cmd.Parameters.AddWithValue("@district", bo.District);
            cmd.Parameters.AddWithValue("@state", bo.State);
            cmd.Parameters.AddWithValue("@country", bo.Country);
            cmd.Parameters.AddWithValue("@bankname", bo.BankName);
            cmd.Parameters.AddWithValue("@bankaccount", bo.BankAccount);
            cmd.Parameters.AddWithValue("@branch", bo.Branch);
            cmd.Parameters.AddWithValue("@ifsccode", bo.IFSCCode);
            cmd.Parameters.AddWithValue("@createdby", bo.Createdby);
            cmd.Parameters.AddWithValue("@createddate", bo.CreatedDate);
            cmd.Parameters.AddWithValue("@modifiedby", bo.Modifiedby);
            cmd.Parameters.AddWithValue("@modifieddate", bo.ModifiedDate);
            cmd.Parameters.AddWithValue("@status", bo.Status);
            SqlParameter SROid = cmd.Parameters.Add("@sroid", SqlDbType.Int);
            SROid.Direction = ParameterDirection.Output;
            int i=cmd.ExecuteNonQuery();

             sroid = Convert.ToInt32(cmd.Parameters["@sroid"].Value);
             return i;
        }

        public int alert()
        {
            return sroid;
        }
        

    }
}
